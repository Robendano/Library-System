module Lito {
    requires javafxg.controls;
    requires javafx.fxml;
    requires java.sql;
    opens sample;
}
