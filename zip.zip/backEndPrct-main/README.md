# Libralirium
# Description
This program is basedoohnaKLibrary Systuesming “Java
Programming Language”. For that we used JavaFX in this
development so that it will become easy with graphical interface
another word with Scene Builderprogram.
Besides, I also studied MySQL for storing data in Database

# Screenshots
When user executes this program, it will show this:

![3](https://user-images.githubusercontent.com/49878695/112358863-e95f9480-8cfa-11eb-952c-00d6093eca76.PNG)

There is my main menu, as you can see there are two options .
After clicking Sign up you will see this:

![2](https://user-images.githubusercontent.com/49878695/112358858-e8c6fe00-8cfa-11eb-9d3b-341d86376f2d.PNG)

It is my registration form to creating new user that will have opportunity t
my program

![1](https://user-images.githubusercontent.com/49878695/112358869-e9f82b00-8cfa-11eb-9e07-62cd171c705f.PNG)

![22](https://user-images.githubusercontent.com/49878695/112360054-1a8c9480-8cfc-11eb-8a5c-1a6ed7b0fd12.PNG)

![33](https://user-images.githubusercontent.com/49878695/112360058-1bbdc180-8cfc-11eb-8914-f2fa0c0afbbc.PNG)

![44](https://user-images.githubusercontent.com/49878695/112360060-1bbdc180-8cfc-11eb-8f5c-4a99c640565a.PNG)

![55](https://user-images.githubusercontent.com/49878695/112360062-1c565800-8cfc-11eb-8fd9-d1ab9f0cd872.PNG)

![11](https://user-images.githubusercontent.com/49878695/112360063-1c565800-8cfc-11eb-8cfb-d13b505083de.PNG)
